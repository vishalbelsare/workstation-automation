#!/bin/sh -e
# ESET Remote Administrator (OnlineInstallerScript)
# Copyright (c) 1992-2016 ESET, spol. s r.o. All Rights Reserved

files2del="$(mktemp -q /tmp/XXXXXXXX.files)"
dirs2del="$(mktemp -q /tmp/XXXXXXXX.dirs)"
echo "$dirs2del" >> "$files2del"
dirs2umount="$(mktemp -q /tmp/XXXXXXXX.mounts)"
echo "$dirs2umount" >> "$files2del"

finalize()
{
  set +e

  echo "Cleaning up:"

  if test -f "$dirs2umount"
  then
    while read f
    do
      sudo -S hdiutil detach "$f"
    done < "$dirs2umount"
  fi

  if test -f "$dirs2del"
  then
    while read f
    do
      test -d "$f" && rmdir "$f"
    done < "$dirs2del"
  fi

  if test -f "$files2del"
  then
    while read f
    do
      unlink "$f"
    done < "$files2del"
    unlink "$files2del"
  fi
}

trap 'finalize' HUP INT QUIT TERM EXIT

eraa_server_hostname="eraserver.dynoquant.com"
eraa_server_port="2222"
eraa_peer_cert_b64="MIIJhQIBAzCCCU8GCSqGSIb3DQEHAaCCCUAEggk8MIIJODCCA+8GCSqGSIb3DQEHBqCCA+AwggPcAgEAMIID1QYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIey71Sd5FY/wCAggAgIIDqEHzCjVvkBX5tEq/4QGUi6zELHHlUwkdKJ4TCvIXwfX/NtDjGe9u5CWUAC2JukuSc5pBKXsJhxSSlbg+ZCahy+Oz4sJ3dCOcGfTI1+hxU9AH4wJCA9+6+plMKsPzqKsxNArRIqYStQL1vlsGXkpgfgX29D5mkncxg5GP6j29psjbStryEE3KQhZ39TyBB8Wt9qzU7kWXb5EID4SjKh3UJkLZ4At+E8FwAoxf2j+vmu+MNYDng2oFk6eMH8rpK7VFqm98+uSBAhcJxnj7UtaMiB3GGiiaoRa4szgttflwQcbtlN/A4EQ1TeL6tTx+o6U4S8haFttAN4Am62EQWPw+1tIINy0Z2e9YpDKXnsrPxaZ0KuRPm44pTNFiBdD5GA4MZTD2Ie0cHJ3f5WB0F90pkp1lrycPHRWSZbCa647AUYDx+sp4CJKcX9xVTcAWw0NSKZlnl4T+oKzKEe30bSPHMcc9aN1amHlw3MNbB2gekhZjZVsDzVqHGuVQlXlyJJoylW7hy6BgKSwqWhBnFhph3m7U3zp+QKuHJTL9cCb4gdqHvJH+pepLZUIez0cDSHQuMl13f0gCxUnfrJ9yLO5QYWXjk69YjceG9eZ56IdAGn+bOvHe2/MwGDVJ2DFJsSdOhyYo9OkkJkuOywLBF2fj9iFx2+OzIVBhNsMLhQSlk1P92HV5p15p6w4nm7veaPk1PGOp+DrG/vfK2olV79atthRFpmEW7C3gZTYiKGyuzxyN3WkHULeZZwZMVPo96ECu9dqOAYcuvkTcEGToe2x/mnb0CYgj7Ci7a+unzX5x/DSE+QPqDyjCFTyxfabVm7P7TMpt5eVWv/VugBZGwXoDY2SWI+Jhf4llEmlJ7YyrYHb01EkinstLMuRX6B+2w8g6oTty0OHL0/uJ0kfEsAYxiLUIqlHFIQqUmURuD5w58AIw1pqkIVecjpHXgWVqKGnHs17eGNQ8RmbZx4PdkQV/kg6fLHTFLglY/Xqs2Nj4fkv/mv7XVe/SUaUWommT14S7vb5aYfp2SrUeZst92y+auBhU5thRHAwpKSroF6uKoVY8Vvkcl4vgfPQag1hmyURWCuozi8xDtldD16ommNTxwhMWwkhCf1/RXp28CtuBmzZw/dkax+UdXix302i0ktvaNMr7xqKjXqMTF2jHDOhDaPm1PJ3fTWTRPMjU9imYkUzFNEQXVGaxrsRvHURN7U2CV/H8mhvvZ0XkseECNeOYqUis3Y9dqIIlpTCCBUEGCSqGSIb3DQEHAaCCBTIEggUuMIIFKjCCBSYGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBAzAOBAhVgJgdNd5GdwICCAAEggTIrVSFQasbzD2FpX3Eyp9QJpL7H9sg8l8sdH2PBNpksRicF+2qbWZNEvVwyZZHxNwqh4CXII0vcXeW/oV1GW/ZJ1x711i7mDn43vixSM5DmaQfMja/w8PWsWpLWdsxTFzI/YOwAr3KmR24gRd7vVMd78DZ0If2kjR24PxafrZenO+v87mkKE3CLGYFCDMkdaeGsYpakX5Fp61hRNEKJXpfl9VUuxNexESKYt2Gdnvc/KHpFGn1kojSSfEQzv/GtQwwM4zvmsSE4ycxpHyn+lzDojA4ub0EShnie3uAYLEQxNuScMacTzozWcPFMEuz2ecspepBXtY1LvWSz22ngdVaD/xyH4b9rQULDskyQyLXsjUMikmWxGoa+ZOmrYu5naXHFMGon3gznq53ksfRKFWh9YbZFB5KQyE0r6Ofl4WNxjC9yUFI0m9QtsVrLMIRVW60i+aZSdhwJy6NMekEoy1B9nJyaI3LiNZBipNssZPeqtMdH/CZVx2Fs0M2QOOGC6y5M3XY4K+TwR0BMCkT+563poz1E+Ha96f2tLda1obtd8+lojr1To3ytq7mlMPq8c9YWNdoVDc2O6k9e/MgjzhnFYXUHMNjKL7OwieXK6M18NMcEEXjHaFXGFZY2p7vqjFIR+EDWkuaS0Nm1TYfYU5MVFlC7OS9qGpnYTuFzY0/T/lG13ExWTVW1+42F0QSjFa/NL9nss4HSOM/gi/atedAsskAVNpI7wOGoDg0oaW/GWOqInkN3LWvg/ChqFFuzU9Dfxi/rnhXF3sC3El/0Vcez1+Ybgt30Frxp2beCtBpT2cL2EZQ46cmLrOQn8VBOlKlGL7nxSF8nCyLtN74Fxdu5x0gpE8O1/hHoMOWTiVu2FC+Na87+D6CnK7TdXl9Nd/6JsyWjbRy54vo/35QI0gz4NSkpKChssYX7/6enDF5ErZQMBdekxSQnhhlYGNzf3BY/Jcx/A+iL3fu5Uimvn1OaVhkvCxcpxKtPzM5Ht13Npgpm5PSVngoBNxhVvE6/SzzpdmMk3kAugVk9KbbY7MUTdU1fU4grkp9VJC6bRhvzXgWFYHUBMzpSYWkO4zd6rhye8eL3cQb+qq9s8dsNPi1Pd/LlfRMmWzXT7E2wYpolkqMiM0bdl4HHqN6pN0Uj5uCCovv9SMb8NgC4YATV9pLIVYjku8MOy3+3xPo42n9kD7tafUEkcow2mhgGrFMDUkAbvGis1mU1dAIXAIKz0DgrjJshIZspgv5oVYIwsuZkTub2f0rTz4tcDAIv0RQlU02TS7feValFcVoKuA/tpTfjDl1vPVXZFoMIVWyzeaBfqojremr58WfitM7R5FVcLsJLoE37NjjhXktG+9RnuzOl13HAYyx5t0yKYbUh3NdfekWZlQdBuFOeT35muwKwevR6YLR1UxT7oRtZnKy+g+B/bWUM6v4N3sk/dGOgOQFE5TgEux23QKsGV7K0XpnnPRl+vZ8m/yBJnLn5K5WTrkvQBj4iodi0qmujdWwYySS01IzxeCD0QWatQB362ebXVE2/af7pt8ZwwNGP2DG10wwJmsqzfdhJYK7rgV2H3VZwCJkPBDdo+umero6ENYbhLgg2YuVq2xE13y8/fFtqcyO3DA9zxBJfpUlMSUwIwYJKoZIhvcNAQkVMRYEFJxrgTRstjjGkNB+st67iRgSdD9WMC0wITAJBgUrDgMCGgUABBTNKg43xI+iUMY/iZKXHILSMUXmxAQImp2HvLxlI5k="
eraa_peer_cert_pwd=""
eraa_ca_cert_b64="MIIDWzCCAkOgAwIBAgISAS8RudSq9E/jrXlrW4WrHxABMA0GCSqGSIb3DQEBBQUAMDYxJzAlBgNVBAMMHlNlcnZlciBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTELMAkGA1UEBhMCVVMwHhcNMTYxMjE5MDAwMDAwWhcNMjYxMjIxMDAwMDAwWjA2MScwJQYDVQQDDB5TZXJ2ZXIgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxCzAJBgNVBAYTAlVTMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmvRge7WY72YipVTS433rBUR+cZUSS8wFbalfMkGcnRgHoPOGQqN4u2F5IblodPIpvLdnsNeB4r+LkqxrvTDJ0tCjwlZvXGhFLJys5Ka1Quo69sWTZKoOw5ODNStj1bV0Tilofvqggwr1Bo8uWsbOlsa1Tfl3rk0guobzSEYGqaC/hjrRFo0OrxOy4JsZRdWc45tBbwORhzt6ZB7uf7Vhwj0Vwnv2ZNGOce2o1wTrvaDlN7tf6MlTUm0b87APgXXo0qVYta6c/cP7aBGcmJvZF3O7gRaoylvjE7OIVl0D09/uAvrDt06ntY/z8lHS1M/HjYAOwQyLguAZ7c8HxFYj+wIDAQABo2MwYTAOBgNVHQ8BAf8EBAMCAQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUzHoDcaGE+uNx7lxdRWCoP9O4w4MwHwYDVR0jBBgwFoAUzHoDcaGE+uNx7lxdRWCoP9O4w4MwDQYJKoZIhvcNAQEFBQADggEBAGEfuWsVBTIX1QqMZmB3IC6mBDO0jiYvV4KBstYB5kwhS8i3OrdXBHwHO5x2miDZnNRjS3RJ2JIoTzqaMqRf4GXYnxnXUlDpYnQTPZdg29tCN3h29ztrlelNtr0RaxqG3na9FkFyANaOdG2WU0/jaWS5vdoRURKB26YmdimMpHnVJoSdEVbelpFxUaj6For/zTvjtLrEF0xIvejr9uCilroiMXlMoHFtWR1nn6SCWuRZ2vXlfvdxJVW7Kca+wiWeQJOlVvU+3Vve9t3n7KYYg8RX5eta7VL7edKFf5g3dWNXtZbUN9iS4chTq0KYzDERF0EfOKscW5OvRtfxUxQayAY="
eraa_product_uuid=""

eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v6/6.5.376.0/agent-macosx-i386.dmg"
eraa_installer_checksum="9b28a28ea75d0325f1b3f56661e747bbe84ba895"
eraa_initial_sg_token=""

arch=$(uname -m)
if $(echo "$arch" | grep -E "^(x86_64|amd64)$" 2>&1 >> /dev/null)
then
    eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v6/6.5.376.0/agent-macosx-i386.dmg"
    eraa_installer_checksum="9b28a28ea75d0325f1b3f56661e747bbe84ba895"
fi

if test -z $eraa_installer_url
then
  echo "No installer available for '$arch' arhitecture. Sorry :/"
  exit 1
fi

local_params_file="/tmp/postflight.plist"
echo "$local_params_file" >> "$files2del"

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" >> "$local_params_file"
echo "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">" >> "$local_params_file"
echo "<plist version=\"1.0\">" >> "$local_params_file"
echo "<dict>" >> "$local_params_file"

echo "  <key>Hostname</key><string>$eraa_server_hostname</string>" >> "$local_params_file"

echo "  <key>Port</key><string>$eraa_server_port</string>" >> "$local_params_file"

if test -n "$eraa_peer_cert_pwd"
then
  echo "  <key>PeerCertPassword</key><string>$eraa_peer_cert_pwd</string>" >> "$local_params_file"
  echo "  <key>PeerCertPasswordIsBase64</key><string>yes</string>" >> "$local_params_file"
fi

echo "  <key>PeerCertContent</key><string>$eraa_peer_cert_b64</string>" >> "$local_params_file"


if test -n "$eraa_ca_cert_b64"
then
  echo "  <key>CertAuthContent</key><string>$eraa_ca_cert_b64</string>" >> "$local_params_file"
fi
if test -n "$eraa_product_uuid"
then
  echo "  <key>ProductGuid</key><string>$eraa_product_uuid</string>" >> "$local_params_file"
fi
if test -n "$eraa_initial_sg_token"
then
  echo "  <key>InitialStaticGroup</key><string>$eraa_initial_sg_token</string>" >> "$local_params_file"
fi

echo "</dict>" >> "$local_params_file"
echo "</plist>" >> "$local_params_file"

# optional list of G1 migration parameters (MAC, UUID, LSID)
local_migration_list="$(mktemp -q /tmp/XXXXXXXX.migration)"
tee "$local_migration_list" 2>&1 > /dev/null << __LOCAL_MIGRATION_LIST__

__LOCAL_MIGRATION_LIST__
test $? = 0 && echo "$local_migration_list" >> "$files2del"

# get all local MAC addresses (normalized)
for mac in $(ifconfig -a | grep ether | sed -e "s/^[[:space:]]ether[[:space:]]//g")
do
    macs="$macs $(echo $mac | sed 's/\://g' | awk '{print toupper($0)}')"
done

while read line
do
  if test -n "$macs" -a -n "$line"
  then
    mac=$(echo $line | awk '{print $1}')
    uuid=$(echo $line | awk '{print $2}')
    lsid=$(echo $line | awk '{print $3}')
    if $(echo "$macs" | grep "$mac" > /dev/null)
    then
      if test -n "$mac" -a -n "$uuid" -a -n "$lsid"
      then
        /usr/libexec/PlistBuddy -c "Add :ProductGuid string $uuid" "$local_params_file"
        /usr/libexec/PlistBuddy -c "Add :LogSequenceID integer $lsid" "$local_params_file"
         break
      fi
    fi
  fi
done < "$local_migration_list"

local_dmg="$(mktemp -q -u /tmp/EraAgentOnlineInstaller.dmg.XXXXXXXX)"
echo "Downloading installer image '$eraa_installer_url':"

eraa_http_proxy_value=""
if test -n "$eraa_http_proxy_value"
then
  export use_proxy=yes
  export http_proxy="$eraa_http_proxy_value"
  (curl --connect-timeout 300 --insecure -o "$local_dmg" "$eraa_installer_url" || curl --connect-timeout 300 --noproxy "*" --insecure -o "$local_dmg" "$eraa_installer_url") && echo "$local_dmg" >> "$files2del"
else
  curl --connect-timeout 300 --insecure -o "$local_dmg" "$eraa_installer_url" && echo "$local_dmg" >> "$files2del"
fi

os_version=$(system_profiler SPSoftwareDataType | grep "System Version" | awk '{print $6}' | sed "s:.[[:digit:]]*.$::g")
if test "10.7" = "$os_version"
then
  local_sha1="$(mktemp -q -u /tmp/EraAgentOnlineInstaller.sha1.XXXXXXXX)"
  echo "$eraa_installer_checksum  $local_dmg" > "$local_sha1" && echo "$local_sha1" >> "$files2del"
  /bin/echo -n "Checking integrity of of downloaded package " && shasum -c "$local_sha1"
else
  /bin/echo -n "Checking integrity of of downloaded package " && echo "$eraa_installer_checksum  $local_dmg" | shasum -c
fi

local_mount="$(mktemp -q -d /tmp/EraAgentOnlineInstaller.mount.XXXXXXXX)" && echo "$local_mount" | tee "$dirs2del" >> "$dirs2umount"
echo "Mounting image '$local_dmg':" && sudo -S hdiutil attach "$local_dmg" -mountpoint "$local_mount" -nobrowse

local_pkg="$(ls "$local_mount" | grep "\.pkg$" | head -n 1)"

echo "Installing package '$local_mount/$local_pkg':" && sudo -S installer -pkg "$local_mount/$local_pkg" -target /
